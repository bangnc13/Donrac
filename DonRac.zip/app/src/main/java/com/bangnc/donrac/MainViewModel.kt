package com.bangnc.donrac

import android.app.Application
import android.os.Environment
import android.text.format.Formatter
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var scanJob: Job? = null

    private val appCtx: Application get() = getApplication()

    init {
        refreshSystem()
    }

    fun refreshSystem() {
        val (total, free) = Sys.storage()
        val (ramTotal, ramFree) = Sys.ram(appCtx)
        val files = Sys.hasFileAccess()
        val usage = Sys.hasUsageAccess(appCtx)
        _state.update {
            it.copy(
                storageTotal = total,
                storageFree = free,
                ramTotal = ramTotal,
                ramFree = ramFree,
                hasFileAccess = files,
                hasUsageAccess = usage,
            )
        }
    }

    fun onResume() {
        refreshSystem()
        val s = _state.value
        if (s.appsLoaded && s.hasUsageAccess) loadApps()
    }

    fun consumeMessage() {
        _state.update { it.copy(message = null) }
    }

    // ---- Quét rác ----

    fun startScan() {
        val s = _state.value
        if (s.scanning || s.cleaning || !s.hasFileAccess) return
        scanJob = viewModelScope.launch {
            _state.update {
                it.copy(
                    scanning = true,
                    scanned = 0,
                    result = null,
                    selected = emptySet(),
                    expanded = emptySet(),
                )
            }
            try {
                val job = coroutineContext[Job]!!
                val res = withContext(Dispatchers.IO) {
                    JunkScanner.scan(Environment.getExternalStorageDirectory(), job) { n ->
                        _state.update { it.copy(scanned = n) }
                    }
                }
                val picked = HashSet<String>()
                for (cat in Cat.entries) {
                    if (!cat.defaultOn) continue
                    val list = res.byCat[cat] ?: continue
                    for (item in list) picked.add(item.path)
                }
                _state.update { it.copy(scanning = false, result = res, selected = picked) }
            } catch (e: CancellationException) {
                _state.update { it.copy(scanning = false) }
                throw e
            } catch (e: Exception) {
                _state.update {
                    it.copy(scanning = false, message = "Không quét được: ${e.message ?: "lỗi không rõ"}")
                }
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
    }

    // ---- Chọn mục ----

    fun toggleItem(path: String) {
        _state.update {
            it.copy(selected = if (path in it.selected) it.selected - path else it.selected + path)
        }
    }

    fun toggleCat(cat: Cat) {
        val list = _state.value.result?.byCat?.get(cat) ?: return
        val paths = list.map { it.path }
        _state.update {
            val all = paths.all { p -> p in it.selected }
            it.copy(selected = if (all) it.selected - paths.toSet() else it.selected + paths)
        }
    }

    fun toggleExpand(cat: Cat) {
        _state.update {
            it.copy(expanded = if (cat in it.expanded) it.expanded - cat else it.expanded + cat)
        }
    }

    // ---- Xóa ----

    fun cleanSelected() {
        val s = _state.value
        val res = s.result ?: return
        if (s.cleaning) return
        val items = res.all().filter { it.path in s.selected }
        if (items.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(cleaning = true) }
            val rep = withContext(Dispatchers.IO) { JunkScanner.delete(appCtx, items) }

            val left = HashMap<Cat, List<Item>>()
            for ((cat, list) in res.byCat) {
                val keep = list.filter { row -> row.path !in rep.removed }
                if (keep.isNotEmpty()) left[cat] = keep
            }
            val msg = buildString {
                append("Đã xóa ${rep.removed.size} mục, giải phóng ${Formatter.formatFileSize(appCtx, rep.freed)}")
                if (rep.failed > 0) {
                    append(". Không xóa được ${rep.failed} mục (đang được dùng hoặc bị hệ thống chặn)")
                }
            }
            _state.update {
                it.copy(
                    cleaning = false,
                    result = ScanResult(left),
                    selected = it.selected - rep.removed,
                    message = msg,
                )
            }
            refreshSystem()
        }
    }

    // ---- RAM ----

    fun boostRam() {
        viewModelScope.launch {
            val before = Sys.ram(appCtx).second
            withContext(Dispatchers.IO) { Sys.boostRam(appCtx) }
            delay(1200)
            refreshSystem()
            val gained = Sys.ram(appCtx).second - before
            val msg = if (gained > 50L * 1024 * 1024) {
                "Đã giải phóng ${Formatter.formatFileSize(appCtx, gained)} RAM"
            } else {
                "RAM gần như không đổi. Android tự quản lý RAM nên thường không cần dọn thủ công"
            }
            _state.update { it.copy(message = msg) }
        }
    }

    // ---- Ứng dụng ----

    fun loadApps() {
        if (_state.value.appsLoading) return
        viewModelScope.launch {
            _state.update { it.copy(appsLoading = true) }
            val list = withContext(Dispatchers.IO) { Sys.loadApps(appCtx) }
            _state.update { it.copy(apps = list, appsLoading = false, appsLoaded = true) }
        }
    }
}
