package com.bangnc.donrac

import android.Manifest
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.UserHandle
import android.os.storage.StorageManager

object Sys {
    /** Trả về (tổng, còn trống) của bộ nhớ trong. */
    @Suppress("DEPRECATION")
    fun storage(): Pair<Long, Long> {
        val st = StatFs(Environment.getExternalStorageDirectory().path)
        return Pair(st.totalBytes, st.availableBytes)
    }

    /** Trả về (tổng, còn trống) của RAM. */
    fun ram(ctx: Context): Pair<Long, Long> {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return Pair(mi.totalMem, mi.availMem)
    }

    fun hasFileAccess(): Boolean = Environment.isExternalStorageManager()

    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            ctx.packageName,
        )
        return if (mode == AppOpsManager.MODE_DEFAULT) {
            ctx.checkSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            mode == AppOpsManager.MODE_ALLOWED
        }
    }

    /** Đọc dung lượng bộ nhớ đệm từng ứng dụng (cần quyền Usage access). */
    @Suppress("DEPRECATION")
    fun loadApps(ctx: Context): List<AppRow> {
        val pm = ctx.packageManager
        val ssm = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val rows = ArrayList<AppRow>()
        for (ai in pm.getInstalledApplications(0)) {
            try {
                val st = ssm.queryStatsForPackage(
                    StorageManager.UUID_DEFAULT,
                    ai.packageName,
                    UserHandle.getUserHandleForUid(ai.uid),
                )
                rows.add(
                    AppRow(
                        label = ai.loadLabel(pm).toString(),
                        pkg = ai.packageName,
                        cache = st.cacheBytes,
                        data = st.dataBytes,
                        isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                    )
                )
            } catch (e: Exception) {
                // bỏ qua ứng dụng không đọc được
            }
        }
        return rows.sortedByDescending { it.cache }
    }

    /** Yêu cầu hệ thống dừng tiến trình nền của các ứng dụng người dùng (trừ chính app này). */
    @Suppress("DEPRECATION")
    fun boostRam(ctx: Context) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (ai in ctx.packageManager.getInstalledApplications(0)) {
            if (ai.packageName == ctx.packageName) continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            if ((ai.flags and ApplicationInfo.FLAG_STOPPED) != 0) continue
            am.killBackgroundProcesses(ai.packageName)
        }
    }
}
