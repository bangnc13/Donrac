package com.bangnc.donrac

enum class Cat(val title: String, val hint: String, val defaultOn: Boolean) {
    TEMP("Tệp tạm và nhật ký", "Tệp .tmp, .log, tải dở dang, đã cũ hơn 1 giờ", true),
    THUMB("Ảnh xem trước", "Bộ nhớ đệm ảnh thu nhỏ, hệ thống tự tạo lại khi cần", true),
    EMPTY("Thư mục trống", "Thư mục không chứa tệp nào", true),
    APK("Tệp cài đặt APK", "Bộ cài đã tải về, xem kỹ trước khi xóa", false),
    LARGE("Tệp lớn từ 100 MB", "Video, bản sao lưu… hãy tự chọn tệp muốn xóa", false),
}

data class Item(
    val path: String,
    val size: Long,
    val cat: Cat,
    val isDir: Boolean = false,
)

class ScanResult(val byCat: Map<Cat, List<Item>>) {
    val totals: Map<Cat, Long> = byCat.mapValues { entry -> entry.value.sumOf { it.size } }
    fun all(): List<Item> = byCat.values.flatten()
}

data class CleanReport(
    val freed: Long,
    val removed: Set<String>,
    val failed: Int,
)

data class AppRow(
    val label: String,
    val pkg: String,
    val cache: Long,
    val data: Long,
    val isSystem: Boolean,
)

data class UiState(
    val storageTotal: Long = 0L,
    val storageFree: Long = 0L,
    val ramTotal: Long = 0L,
    val ramFree: Long = 0L,
    val hasFileAccess: Boolean = false,
    val hasUsageAccess: Boolean = false,
    val scanning: Boolean = false,
    val scanned: Int = 0,
    val result: ScanResult? = null,
    val selected: Set<String> = emptySet(),
    val expanded: Set<Cat> = emptySet(),
    val cleaning: Boolean = false,
    val apps: List<AppRow> = emptyList(),
    val appsLoading: Boolean = false,
    val appsLoaded: Boolean = false,
    val message: String? = null,
)
