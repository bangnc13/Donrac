package com.bangnc.donrac

import android.content.Context
import android.os.Environment
import android.text.format.Formatter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TriStateCheckbox
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlin.math.roundToInt

// ---------- Giao diện ----------

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F766E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD5EEE8),
    onPrimaryContainer = Color(0xFF0B3B36),
    secondaryContainer = Color(0xFFD5EEE8),
    onSecondaryContainer = Color(0xFF0B3B36),
    background = Color(0xFFEEF4F2),
    onBackground = Color(0xFF12222B),
    surface = Color(0xFFEEF4F2),
    onSurface = Color(0xFF12222B),
    surfaceVariant = Color(0xFFD4E2DE),
    onSurfaceVariant = Color(0xFF45605B),
    outlineVariant = Color(0xFFC3D5D0),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF4F9F7),
    surfaceContainer = Color(0xFFE6EFEC),
    surfaceContainerHigh = Color(0xFFDEE9E6),
    surfaceContainerHighest = Color(0xFFD8E4E1),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5CCDBB),
    onPrimary = Color(0xFF00382F),
    primaryContainer = Color(0xFF1B4A43),
    onPrimaryContainer = Color(0xFFD5EEE8),
    secondaryContainer = Color(0xFF1B4A43),
    onSecondaryContainer = Color(0xFFD5EEE8),
    background = Color(0xFF0E1A1F),
    onBackground = Color(0xFFE3EEEC),
    surface = Color(0xFF0E1A1F),
    onSurface = Color(0xFFE3EEEC),
    surfaceVariant = Color(0xFF243A40),
    onSurfaceVariant = Color(0xFF9DB5B0),
    outlineVariant = Color(0xFF2D454B),
    surfaceContainerLowest = Color(0xFF0A1418),
    surfaceContainerLow = Color(0xFF122127),
    surfaceContainer = Color(0xFF16272D),
    surfaceContainerHigh = Color(0xFF1C3037),
    surfaceContainerHighest = Color(0xFF223A41),
)

@Composable
fun DonRacTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}

// ---------- Tiện ích ----------

fun fmt(ctx: Context, bytes: Long): String = Formatter.formatFileSize(ctx, bytes)

class Stats(val perCat: Map<Cat, Int>, val count: Int, val size: Long)

fun computeStats(res: ScanResult?, sel: Set<String>): Stats {
    val per = HashMap<Cat, Int>()
    var count = 0
    var size = 0L
    if (res != null) {
        for ((cat, list) in res.byCat) {
            var c = 0
            for (i in list) {
                if (i.path in sel) {
                    c++
                    size += i.size
                }
            }
            per[cat] = c
            count += c
        }
    }
    return Stats(per, count, size)
}

fun summaryText(stats: Stats, ctx: Context): String {
    val sizePart = if (stats.size > 0L) ", " + fmt(ctx, stats.size) else ""
    return "${stats.count} mục$sizePart"
}

@Suppress("DEPRECATION")
fun shortParent(path: String): String {
    val root = Environment.getExternalStorageDirectory().path
    val p = File(path).parent ?: return ""
    return if (p.startsWith(root)) "Bộ nhớ trong" + p.removePrefix(root) else p
}

// ---------- Khung chính ----------

@Composable
fun AppRoot(
    vm: MainViewModel,
    onGrantFiles: () -> Unit,
    onGrantUsage: () -> Unit,
    onOpenApp: (String) -> Unit,
) {
    val s by vm.state.collectAsState()
    var tab by rememberSaveable { mutableStateOf(0) }
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(s.message) {
        val m = s.message
        if (m != null) {
            snack.showSnackbar(m)
            vm.consumeMessage()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("🧹", fontSize = 20.sp) },
                    label = { Text("Dọn dẹp") },
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("📱", fontSize = 20.sp) },
                    label = { Text("Ứng dụng") },
                )
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) {
                CleanTab(s, vm, onGrantFiles)
            } else {
                AppsTab(s, vm, onGrantUsage, onOpenApp)
            }
        }
    }
}

// ---------- Tab Dọn dẹp ----------

@Composable
fun CleanTab(s: UiState, vm: MainViewModel, onGrantFiles: () -> Unit) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val res = s.result
    val stats = remember(res, s.selected) { computeStats(res, s.selected) }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 16.dp),
        ) {
            item { Hero(s, ctx) }
            item { RamRow(s, ctx) { vm.boostRam() } }

            if (!s.hasFileAccess) {
                item {
                    Notice(
                        title = "Cần quyền quản lý tất cả tệp",
                        body = "Để quét và xóa tệp rác trong bộ nhớ, hãy bật quyền “Cho phép truy cập để quản lý tất cả các tệp” cho ứng dụng này.",
                        action = "Cấp quyền",
                        onClick = onGrantFiles,
                    )
                }
            } else {
                item { ScanBlock(s, onScan = { vm.startScan() }, onCancel = { vm.cancelScan() }) }

                if (res != null) {
                    if (res.byCat.isEmpty()) {
                        item { EmptyResult() }
                    }
                    for (cat in Cat.entries) {
                        val list = res.byCat[cat] ?: continue
                        val selCount = stats.perCat[cat] ?: 0
                        val total = res.totals[cat] ?: 0L
                        val open = cat in s.expanded

                        item(key = "cat-" + cat.name) {
                            CategoryRow(
                                cat = cat,
                                count = list.size,
                                size = total,
                                selCount = selCount,
                                expanded = open,
                                onToggleAll = { vm.toggleCat(cat) },
                                onExpand = { vm.toggleExpand(cat) },
                            )
                        }
                        if (open) {
                            items(list.take(100), key = { row -> row.path }) { row ->
                                ItemRow(row, row.path in s.selected) { vm.toggleItem(row.path) }
                            }
                            if (list.size > 100) {
                                item(key = "more-" + cat.name) {
                                    Text(
                                        "Còn ${list.size - 100} mục nữa trong nhóm này. Chọn cả nhóm để xóa hết.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(start = 28.dp, top = 4.dp, bottom = 8.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (res != null && stats.count > 0) {
            Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
                    Button(
                        onClick = { confirm = true },
                        enabled = !s.cleaning && !s.scanning,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                    ) {
                        Text(if (s.cleaning) "Đang xóa…" else "Xóa " + summaryText(stats, ctx))
                    }
                }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Xóa vĩnh viễn?") },
            text = { Text("Sẽ xóa " + summaryText(stats, ctx) + ". Thao tác này không thể hoàn tác.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    vm.cleanSelected()
                }) {
                    Text("Xóa", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("Hủy") }
            },
        )
    }
}

@Composable
fun StorageRing(frac: Float, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val bar = MaterialTheme.colorScheme.primary
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 18.dp.toPx()
            val inset = stroke / 2f
            val arc = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = track,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arc,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            drawArc(
                color = bar,
                startAngle = 135f,
                sweepAngle = 270f * frac.coerceIn(0f, 1f),
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arc,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
        }
        content()
    }
}

@Composable
fun Hero(s: UiState, ctx: Context) {
    val used = (s.storageTotal - s.storageFree).coerceAtLeast(0L)
    val frac = if (s.storageTotal > 0L) used.toFloat() / s.storageTotal.toFloat() else 0f
    val anim by animateFloatAsState(targetValue = frac, animationSpec = tween(900), label = "ring")

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "Dọn rác",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.Start),
        )
        Spacer(Modifier.height(12.dp))
        StorageRing(anim, Modifier.size(220.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${(anim * 100).roundToInt()}%", fontSize = 44.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "bộ nhớ đã dùng",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            Stat("Đã dùng", fmt(ctx, used), Modifier.weight(1f))
            Stat("Còn trống", fmt(ctx, s.storageFree), Modifier.weight(1f))
            Stat("Tổng", fmt(ctx, s.storageTotal), Modifier.weight(1f))
        }
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun SizeBar(frac: Float, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Box(
            Modifier
                .fillMaxWidth(frac.coerceIn(0f, 1f))
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.primary)
        )
    }
}

@Composable
fun RamRow(s: UiState, ctx: Context, onBoost: () -> Unit) {
    val used = (s.ramTotal - s.ramFree).coerceAtLeast(0L)
    val frac = if (s.ramTotal > 0L) used.toFloat() / s.ramTotal.toFloat() else 0f
    Column(Modifier.fillMaxWidth().padding(top = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("RAM", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "${fmt(ctx, used)} trên ${fmt(ctx, s.ramTotal)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = onBoost) { Text("Giải phóng") }
        }
        SizeBar(frac)
        Text(
            "Chỉ dừng tiến trình nền. Android có thể tự mở lại một số ứng dụng.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
fun Notice(title: String, body: String, action: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(top = 20.dp),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                body,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = onClick) { Text(action) }
        }
    }
}

@Composable
fun ScanBlock(s: UiState, onScan: () -> Unit, onCancel: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 8.dp)) {
        if (s.scanning) {
            val n = "%,d".format(s.scanned)
            Text("Đang quét, đã duyệt $n tệp", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            TextButton(onClick = onCancel) { Text("Dừng") }
        } else {
            Button(
                onClick = onScan,
                enabled = !s.cleaning,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) {
                Text(if (s.result == null) "Quét rác" else "Quét lại")
            }
            if (s.result == null) {
                Text(
                    "Quét chỉ liệt kê tệp rác. Không có gì bị xóa cho đến khi bạn xác nhận.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

@Composable
fun EmptyResult() {
    Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
        Text(
            "Không tìm thấy rác",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            "Bộ nhớ đã gọn. Quét lại sau khi dùng máy một thời gian.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun CategoryRow(
    cat: Cat,
    count: Int,
    size: Long,
    selCount: Int,
    expanded: Boolean,
    onToggleAll: () -> Unit,
    onExpand: () -> Unit,
) {
    val ctx = LocalContext.current
    val state = when {
        selCount == 0 -> ToggleableState.Off
        selCount >= count -> ToggleableState.On
        else -> ToggleableState.Indeterminate
    }
    val sizePart = if (size > 0L) ", " + fmt(ctx, size) else ""
    Column(Modifier.fillMaxWidth()) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onExpand).padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TriStateCheckbox(state = state, onClick = onToggleAll)
            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                Text(cat.title, style = MaterialTheme.typography.titleMedium)
                Text(
                    "$count mục$sizePart",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    cat.hint,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                if (expanded) "Thu gọn" else "Xem",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
fun ItemRow(row: Item, checked: Boolean, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val name = remember(row.path) { File(row.path).name }
    val parent = remember(row.path) { shortParent(row.path) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(start = 28.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
        Column(Modifier.weight(1f)) {
            Text(
                name,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                parent,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (row.size > 0L) {
            Text(
                fmt(ctx, row.size),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 12.dp),
            )
        }
    }
}

// ---------- Tab Ứng dụng ----------

@Composable
fun AppsTab(
    s: UiState,
    vm: MainViewModel,
    onGrantUsage: () -> Unit,
    onOpenApp: (String) -> Unit,
) {
    val ctx = LocalContext.current
    var showSystem by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(s.hasUsageAccess) {
        if (s.hasUsageAccess && !s.appsLoaded) vm.loadApps()
    }

    val list = remember(s.apps, showSystem) { s.apps.filter { showSystem || !it.isSystem } }
    val total = remember(list) { list.sumOf { it.cache } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
    ) {
        item {
            Text(
                "Ứng dụng",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
            )
        }
        if (!s.hasUsageAccess) {
            item {
                Notice(
                    title = "Cần quyền xem dữ liệu sử dụng",
                    body = "Android chỉ cho xem dung lượng bộ nhớ đệm của từng ứng dụng khi bạn bật quyền này cho Dọn Rác.",
                    action = "Cấp quyền",
                    onClick = onGrantUsage,
                )
            }
        } else {
            item {
                Column(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp)) {
                    Text(fmt(ctx, total), fontSize = 36.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "bộ nhớ đệm trong ${list.size} ứng dụng",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        "Chạm vào một ứng dụng, chọn Bộ nhớ (hoặc Lưu trữ), rồi Xóa bộ nhớ đệm. Android không cho ứng dụng thường tự xóa bộ nhớ đệm của ứng dụng khác.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            "Hiện cả ứng dụng hệ thống",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f),
                        )
                        Switch(checked = showSystem, onCheckedChange = { showSystem = it })
                    }
                }
            }
            if (s.appsLoading && s.apps.isEmpty()) {
                item { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()) }
            }
            items(list, key = { a -> a.pkg }) { a ->
                AppRowItem(a) { onOpenApp(a.pkg) }
            }
        }
    }
}

@Composable
fun AppRowItem(a: AppRow, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Row(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text(
                    a.label,
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "Dữ liệu " + fmt(ctx, a.data),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                fmt(ctx, a.cache),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}
