package com.bangnc.donrac

import android.content.Context
import android.media.MediaScannerConnection
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import java.io.File
import java.nio.file.Files

object JunkScanner {
    private val TEMP_EXT = setOf(
        "tmp", "temp", "log", "dmp", "chk",
        "crdownload", "part", "partial", "download", "opdownload",
    )
    private val STANDARD_DIRS = setOf(
        "dcim", "download", "downloads", "pictures", "movies", "music", "documents",
        "alarms", "notifications", "ringtones", "podcasts", "audiobooks", "recordings",
        "screenshots", "android",
    )
    private const val LARGE_MIN = 100L * 1024 * 1024
    private const val MIN_AGE_MS = 60L * 60 * 1000

    private class Ctx(val job: Job, val onProgress: (Int) -> Unit) {
        val now: Long = System.currentTimeMillis()
        val out = HashMap<Cat, MutableList<Item>>()
        var visited = 0

        fun add(item: Item) {
            out.getOrPut(item.cat) { ArrayList() }.add(item)
        }
    }

    /** Quét toàn bộ bộ nhớ chung, chỉ liệt kê, không xóa gì. */
    fun scan(root: File, job: Job, onProgress: (Int) -> Unit): ScanResult {
        val ctx = Ctx(job, onProgress)
        walk(root, 0, ctx)
        ctx.onProgress(ctx.visited)
        val map = HashMap<Cat, List<Item>>()
        for (cat in Cat.entries) {
            val list = ctx.out[cat]
            if (list.isNullOrEmpty()) continue
            map[cat] = if (cat == Cat.EMPTY) {
                list.sortedBy { it.path }
            } else {
                list.sortedByDescending { it.size }
            }
        }
        return ScanResult(map)
    }

    /** Trả về true nếu thư mục này (và mọi thứ bên trong) chỉ gồm thư mục trống. */
    private fun walk(dir: File, depth: Int, ctx: Ctx): Boolean {
        ctx.job.ensureActive()
        val kids = dir.listFiles() ?: return false
        var empty = true
        val emptyKids = ArrayList<File>()
        for (k in kids) {
            if (k.isDirectory) {
                if (depth == 0 && k.name.equals("Android", ignoreCase = true)) {
                    empty = false
                    continue
                }
                if (Files.isSymbolicLink(k.toPath())) {
                    empty = false
                    continue
                }
                if (walk(k, depth + 1, ctx)) {
                    emptyKids.add(k)
                } else {
                    empty = false
                }
            } else {
                empty = false
                classify(k, ctx)
            }
        }
        if (!empty) {
            for (e in emptyKids) {
                if (depth == 0 && e.name.lowercase() in STANDARD_DIRS) continue
                ctx.add(Item(e.path, 0L, Cat.EMPTY, true))
            }
        }
        return empty
    }

    private fun classify(f: File, ctx: Ctx) {
        ctx.visited++
        if (ctx.visited % 1000 == 0) {
            ctx.job.ensureActive()
            ctx.onProgress(ctx.visited)
        }
        val path = f.path
        val lower = f.name.lowercase()
        val ext = lower.substringAfterLast('.', "")

        if (path.contains("/.thumbnails/") || lower.startsWith(".thumbdata")) {
            if (isOld(f, ctx)) ctx.add(Item(path, f.length(), Cat.THUMB))
            return
        }
        if (ext in TEMP_EXT) {
            if (isOld(f, ctx)) ctx.add(Item(path, f.length(), Cat.TEMP))
            return
        }
        if (ext == "apk") {
            ctx.add(Item(path, f.length(), Cat.APK))
            return
        }
        val size = f.length()
        if (size >= LARGE_MIN) ctx.add(Item(path, size, Cat.LARGE))
    }

    private fun isOld(f: File, ctx: Ctx): Boolean = ctx.now - f.lastModified() > MIN_AGE_MS

    /** Xóa các mục đã chọn. Thư mục chỉ bị xóa khi thực sự còn trống. */
    fun delete(ctx: Context, items: List<Item>): CleanReport {
        var freed = 0L
        var failed = 0
        val removed = HashSet<String>()
        val mediaPaths = ArrayList<String>()

        for (item in items) {
            if (item.isDir) continue
            val f = File(item.path)
            if (f.delete()) {
                freed += item.size
                removed.add(item.path)
                if (item.cat == Cat.LARGE) mediaPaths.add(item.path)
            } else if (!f.exists()) {
                removed.add(item.path)
            } else {
                failed++
            }
        }

        val dirs = items.filter { it.isDir }.sortedByDescending { it.path.length }
        for (item in dirs) {
            if (deleteEmptyTree(File(item.path))) {
                removed.add(item.path)
            } else {
                failed++
            }
        }

        if (mediaPaths.isNotEmpty()) {
            MediaScannerConnection.scanFile(ctx, mediaPaths.toTypedArray(), null, null)
        }
        return CleanReport(freed, removed, failed)
    }

    private fun deleteEmptyTree(d: File): Boolean {
        if (!d.exists()) return true
        val kids = d.listFiles()
        if (kids != null) {
            for (c in kids) {
                if (c.isDirectory && !Files.isSymbolicLink(c.toPath())) deleteEmptyTree(c)
            }
        }
        return d.delete()
    }
}
