# Dọn Rác

Ứng dụng Android quét và xóa tệp rác, xem bộ nhớ đệm từng ứng dụng, giải phóng RAM.
Kotlin + Jetpack Compose. Yêu cầu Android 11 trở lên.

## Tính năng
- Quét bộ nhớ chung: tệp tạm/log, ảnh thu nhỏ, thư mục trống, APK đã tải, tệp từ 100 MB.
- Quét chỉ liệt kê. Chỉ xóa sau khi bạn chọn và xác nhận.
- Tab Ứng dụng: xếp ứng dụng theo dung lượng bộ nhớ đệm, chạm để mở trang cài đặt của ứng dụng đó.
- Giải phóng RAM: yêu cầu dừng tiến trình nền của ứng dụng người dùng.

## Build bằng GitHub (không cần máy tính)
1. Upload `DonRac.zip` vào gốc repo.
2. Tạo `.github/workflows/build.yml` (nội dung ở file build.yml).
3. Tab Actions chạy xong, tải `DonRac.apk` ở mục Releases.

## Ghi chú
- Khóa ký nằm ở `app/release.jks` (mật khẩu trong `app/build.gradle.kts`). Dùng cá nhân,
  giữ repo ở chế độ riêng tư. Giữ nguyên khóa này để bản sau cài đè được bản trước.
- Android không cho ứng dụng thường đọc `Android/data` của ứng dụng khác, cũng không cho
  tự xóa bộ nhớ đệm của ứng dụng khác. Vì vậy ứng dụng chỉ mở trang cài đặt để bạn bấm xóa.
